document.addEventListener('DOMContentLoaded', () => {
  const testimonials = document.querySelectorAll('.testimonial');
  let index = 0;

  setInterval(() => {
    testimonials[index].classList.remove('visible');
    index = (index + 1) % testimonials.length;
    testimonials[index].classList.add('visible');
  }, 3000);
});
