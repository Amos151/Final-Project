            Safety and Training Company Website
A responsive, modern website for a safety and training company. The website provides users with information about services, training courses, resources, and contact details. It also includes interactive features such as a course enrollment form and a client login area.

                  Project Features
Homepage:
* Hero section with a tagline and call-to-action button.
* Sections for "About Us," "Our Services," "Featured      Courses," and "Client Testimonials."
Courses Page:
* A list of training courses with descriptions and enrollment options.
Resources Page:
* Safety-related articles, downloadable guides, and an FAQ section.
Contact Page:
* Contact form for inquiries and company details.
Course Enrollment Form:
* Allows users to submit their enrollment details (design only, no backend).
Client Login Area:
* Login form for accessing exclusive resources (design only, no backend).

                Technology Stack
HTML5: Semantic structure and layout.
CSS3: Styling and responsive design.
Sass: Modular and reusable styling with variables, mixins, and inheritance.
JavaScript: Interactive features like a testimonials carousel and dynamic includes.

                  Design Choices
Color Scheme
* Primary Color: Blue (#121D31) for trust and professionalism.
* Backgrounds: Light gray for contrast and white for cards.
Typography
* Clear and legible fonts (Arial, sans-serif) for professionalism.
* Headers are bold and large for clarity and emphasis.
Buttons and Hover Effects
* Buttons have a consistent style across the site, with hover effects for interactivity.
* Links are styled minimally but with noticeable hover effects.
Responsiveness
* Fully responsive with breakpoints for mobile, tablet, and desktop views.
* Flexbox and grid used for layout to ensure proper scaling on smaller devices.